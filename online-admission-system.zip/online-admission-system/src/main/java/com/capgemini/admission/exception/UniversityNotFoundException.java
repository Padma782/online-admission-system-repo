package com.capgemini.admission.exception;

public class UniversityNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UniversityNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UniversityNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
