package com.capgemini.admission.exception;

public class ApplicationNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ApplicationNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApplicationNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
