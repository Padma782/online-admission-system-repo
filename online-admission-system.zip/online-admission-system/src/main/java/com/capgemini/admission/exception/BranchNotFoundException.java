package com.capgemini.admission.exception;

public class BranchNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BranchNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BranchNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
