package com.capgemini.admission.exception;

public class PaymentNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
