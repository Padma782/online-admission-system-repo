package com.capgemini.admission.exception;

public class CollegeNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CollegeNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CollegeNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
