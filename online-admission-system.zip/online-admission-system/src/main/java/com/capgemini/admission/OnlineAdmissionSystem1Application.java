package com.capgemini.admission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineAdmissionSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineAdmissionSystem1Application.class, args);
	}

}
